package studentCode;

import java.util.Scanner;

public class MaxOfTwoV2 {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		int first;
		int second;
		
		//YOUR CODE IN HERE
		
		first=myScanner.nextInt();
		second=myScanner.nextInt();
		if (first > second) {
			
			System.out.print(first+ " is greater than " + second);
		}
		else if (second > first)
		{
			System.out.print(second+ " is greater than " + first);
		}
		else {
			System.out.print(first+ " is equal to " + second);
		}
	
		
		//YOUR CODE IN HERE

		//YOUR CODE IN HERE
		
		
		myScanner.close();
	}
	
	
}
